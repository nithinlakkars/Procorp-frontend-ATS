import React, { useEffect, useState } from "react";
import { Container, Row, Col, Card, ListGroup, Modal, Button, Spinner } from "react-bootstrap";
import {
  fetchCandidates,
  fetchUnassignedRequirements,
  fetchAllRequirements,
} from "../../services";

const AccountManagerDashboard = () => {
  const [requirements, setRequirements] = useState([]);
  const [candidates, setCandidates] = useState([]);
  const [postedReqCount, setPostedReqCount] = useState(0);
  const [forwardedCount, setForwardedCount] = useState(0);

  // Modal state
  const [showListModal, setShowListModal] = useState(false);
  const [listTitle, setListTitle] = useState("");
  const [listData, setListData] = useState([]);

  const [showDetailModal, setShowDetailModal] = useState(false);
  const [detailData, setDetailData] = useState(null);

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      setLoading(true);
      const [candidatesRes, unassignedReqsRes, postedRes] = await Promise.all([
        fetchCandidates(),
        fetchUnassignedRequirements(),
        fetchAllRequirements(),
      ]);

      const candidatesList = candidatesRes?.candidates || [];
      const unassignedData = Array.isArray(unassignedReqsRes)
        ? unassignedReqsRes
        : unassignedReqsRes?.data || [];

      const postedData = Array.isArray(postedRes?.data)
        ? postedRes.data
        : Array.isArray(postedRes)
          ? postedRes
          : [];

      setCandidates(candidatesList);
      setRequirements(unassignedData);
      setPostedReqCount(postedData.length);

      const forwarded = candidatesList.filter((c) => c.status === "forwarded-to-sales");
      setForwardedCount(forwarded.length);
    } catch (err) {
      console.error("❌ Failed to load dashboard stats:", err);
    } finally {
      setLoading(false);
    }
  };

  const stats = [
    { title: "New Requirements", value: requirements.length, icon: "bi-briefcase", data: requirements, type: "requirement" },
    { title: "Posted Requirements", value: postedReqCount, icon: "bi-file-earmark-text", data: requirements, type: "requirement" },
    { title: "Submitted Candidates", value: candidates.length, icon: "bi-person-check", data: candidates, type: "candidate" },
    { title: "Forwarded to Sales", value: forwardedCount, icon: "bi-send", data: candidates.filter(c => c.status === "forwarded-to-sales"), type: "candidate" },
  ];

  // Open list modal when card clicked
  const handleCardClick = (stat) => {
    setListTitle(stat.title);
    setListData(stat.data);
    setShowListModal(true);
  };

  // Open detail modal when item clicked
  const handleItemClick = (item) => {
    setDetailData(item);
    setShowDetailModal(true);
  };

  return (
    <Container fluid className="p-4">
      <h4 className="fw-bold mb-4">Account Manager Dashboard</h4>

      {loading ? (
        <div className="text-center">
          <Spinner animation="border" />
        </div>
      ) : (
        <>
          {/* Stat Cards */}
          <Row className="mb-4">
            {stats.map((s, idx) => (
              <Col md={3} key={idx}>
                <Card
                  className="mb-3 shadow-sm"
                  style={{ cursor: "pointer" }}
                  onClick={() => handleCardClick(s)}
                >
                  <Card.Body>
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <Card.Title className="mb-0 fs-6">{s.title}</Card.Title>
                      <i className={`bi ${s.icon} fs-4 text-primary`}></i>
                    </div>
                    <h4 className="fw-bold">{s.value}</h4>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        </>
      )}

      {/* Modal for list */}
      <Modal size="lg" show={showListModal} onHide={() => setShowListModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>{listTitle}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {listData.length === 0 ? (
            <p className="text-muted">No records found</p>
          ) : (
            <ListGroup>
              {listData.map((item, idx) => (
                <ListGroup.Item
                  key={idx}
                  action
                  onClick={() => handleItemClick(item)}
                >
                  {/* Requirement list item */}
                  {item.title && (
                    <div>
                      <strong>{item.title}</strong>
                      <br />
                      <small className="text-muted">{item.description?.slice(0, 50)}...</small>
                    </div>
                  )}

                  {/* Candidate list item */}
                  {item.name && (
                    <div>
                      <strong>{item.name}</strong>
                      <br />
                      <small className="text-muted">{item.email || item.status}</small>
                    </div>
                  )}
                </ListGroup.Item>
              ))}
            </ListGroup>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowListModal(false)}>Close</Button>
        </Modal.Footer>
      </Modal>

      {/* Modal for detail */}
      <Modal size="lg" show={showDetailModal} onHide={() => setShowDetailModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {!detailData ? (
            <p>No details available</p>
          ) : detailData.title ? (
            // Requirement detail
            <div>
              <h5>{detailData.title}</h5>
              <p>{detailData.description}</p>
              <p><strong>Location:</strong> {detailData.locations?.join(", ")}</p>
              <p><strong>Skills:</strong> {detailData.primarySkills}</p>
              <p><strong>Rate:</strong> {detailData.rate}</p>
              <p><strong>Employment Type:</strong> {detailData.employmentType}</p>
            </div>
          ) : (
            // Candidate detail
            <div>
              <h5>{detailData.name}</h5>
              <p><strong>Email:</strong> {detailData.email}</p>
              <p><strong>Status:</strong> {detailData.status}</p>
              <p><strong>Requirement:</strong> {detailData.requirementId?.title || "N/A"}</p>
              <p><strong>Active:</strong> {detailData.isActive ? "Yes" : "No"}</p>
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDetailModal(false)}>Close</Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
};

export default AccountManagerDashboard;
