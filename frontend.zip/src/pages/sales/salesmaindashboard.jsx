import React, { useEffect, useState } from "react";
import { Container, Row, Col, Card, Spinner, Table } from "react-bootstrap";
import axios from "axios";

const API_URL = process.env.REACT_APP_API_URL;

const AccountManagerDashboard = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  const [selectedList, setSelectedList] = useState([]);
  const [listTitle, setListTitle] = useState("");

  // Fetch dashboard stats
  useEffect(() => {
    const fetchStats = async () => {
      try {
        const token = sessionStorage.getItem("token");
        const { data } = await axios.get(`${API_URL}/api/stats/sales-dashboard`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        setStats(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, []);

  if (loading) return <Spinner animation="border" />;

  // Stat cards
  const cards = [
    { title: "Active Requirements", value: stats.activeRequirements, key: "activeRequirementsList" },
    { title: "Closed Requirements", value: stats.closedRequirements, key: "closedRequirementsList" },
    { title: "Active Candidates", value: stats.activeCandidates, key: "activeCandidatesList" },
    { title: "Inactive Candidates", value: stats.inactiveCandidates, key: "inactiveCandidatesList" },
  ];

  // Handle card click
  const handleCardClick = (key, title) => {
    setSelectedList(stats[key] || []);
    setListTitle(title);
  };

  return (
    <Container fluid className="p-4">
      <h4 className="fw-bold mb-4">Sales Dashboard</h4>

      <Row className="mb-4">
        {cards.map((card, idx) => (
          <Col md={3} key={idx}>
            <Card className="mb-3 shadow-sm" onClick={() => handleCardClick(card.key, card.title)} style={{ cursor: "pointer" }}>
              <Card.Body>
                <Card.Title className="mb-0 fs-6">{card.title}</Card.Title>
                <h4 className="fw-bold">{card.value}</h4>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>

      {/* Display selected list */}
      {selectedList.length > 0 && (
        <Card className="shadow-sm mt-4">
          <Card.Body>
            <Card.Title>{listTitle}</Card.Title>
            <div className="table-responsive">
              <Table striped bordered hover>
                <thead>
                  <tr>
                    {listTitle.includes("Requirement") && (
                      <>
                        <th>Requirement ID</th>
                        <th>Position</th>
                        <th>Client</th>
                        <th>Priority</th>
                        <th>Duration</th>
                        <th>Assigned Lead(s)</th>
                        <th>Assigned Recruiter(s)</th>
                      </>
                    )}
                    {listTitle.includes("Candidate") && (
                      <>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Requirement</th>
                        <th>Status</th>
                      </>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {selectedList.map((item) => (
                    <tr key={item._id}>
                      {listTitle.includes("Requirement") && (
                        <>
                          <td>{item.requirementId}</td>
                          <td>{item.title}</td>
                          <td>{item.client}</td>
                          <td>{item.priority}</td>
                          <td>{item.duration || "N/A"}</td>
                          <td>{item.leadAssignedTo?.join(", ")}</td>
                          <td>{item.recruiterAssignedTo?.join(", ")}</td>
                        </>
                      )}
                      {listTitle.includes("Candidate") && (
                        <>
                          <td>{item.name}</td>
                          <td>{item.email}</td>
                          <td>{item.requirementId?.title || item.requirementId}</td>
                          <td>{item.status}</td>
                        </>
                      )}
                    </tr>
                  ))}
                </tbody>
              </Table>
            </div>
          </Card.Body>
        </Card>
      )}
    </Container>
  );
};

export default AccountManagerDashboard;
